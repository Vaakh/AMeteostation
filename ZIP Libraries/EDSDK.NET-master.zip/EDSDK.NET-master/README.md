# EDSDK.NET
C# wrapper for the Canon SDK

Codebase copied from [Canon EDSDK Tutorial in C#](https://www.codeproject.com/Articles/688276/Canon-EDSDK-Tutorial-in-Csharp) and upgraded to Canon SDK 3.6.

## Copyright
Portions of this code remain copyright [Johannes Bildstein](https://github.com/JBildstein) and [Canon Australia Pty Ltd](https://www.canon.com.au/support/support-news/support-news/2016/10/18/03/21/digital-slr-camera-software-developers-kit)  