﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle("EDSDKLib WpfExample Example")]
[assembly: AssemblyDescription("WpfExample Example for  Canon SDK wrapper library")]
[assembly: AssemblyProduct("WpfExample WinForms Example")]
[assembly: AssemblyCopyright("Copyright © Johannes Bildstein 2016")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]