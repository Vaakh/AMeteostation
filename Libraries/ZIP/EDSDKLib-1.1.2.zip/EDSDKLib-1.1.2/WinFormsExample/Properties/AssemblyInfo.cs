﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("EDSDKLib WinForms Example")]
[assembly: AssemblyDescription("WinForms Example for  Canon SDK wrapper library")]
[assembly: AssemblyProduct("EDSDKLib WinForms Example")]
[assembly: AssemblyCopyright("Copyright © Johannes Bildstein 2016")]

[assembly: ComVisible(false)]
[assembly: Guid("ac6b306c-ac16-43c4-8624-54a026a5b822")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]