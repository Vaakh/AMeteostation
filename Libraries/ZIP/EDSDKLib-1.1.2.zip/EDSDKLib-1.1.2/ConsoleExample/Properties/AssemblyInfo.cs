﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("EDSDKLib Console Example")]
[assembly: AssemblyDescription("Console Example for  Canon SDK wrapper library")]
[assembly: AssemblyProduct("EDSDKLib Console Example")]
[assembly: AssemblyCopyright("Copyright © Johannes Bildstein 2016")]

[assembly: ComVisible(false)]
[assembly: Guid("63f44645-7bf9-4de5-9b30-d25ade3b3f76")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]