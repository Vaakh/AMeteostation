//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RAWDevelop.rc
//
#define IDD_DIALOG3                     131
#define IDC_AFFRAME_VIEW                1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
