//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RAWDevelop.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RAWDEVELOP_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDD_DIALOG2                     130
#define IDI_ICON1                       131
#define IDC_CURSOR1                     133
#define IDD_DIALOG3                     134
#define IDC_EDIT1                       1000
#define IDC_RADIO_THM                   1001
#define IDC_EDIT2                       1001
#define IDC_RADIO_FULL                  1002
#define IDC_EDIT3                       1002
#define IDC_EDIT_X                      1003
#define IDC_EDIT4                       1003
#define IDC_EDIT_Y                      1004
#define IDC_EDIT5                       1004
#define IDC_EDIT_W                      1005
#define IDC_EDIT6                       1005
#define IDC_EDIT_H                      1006
#define IDC_EDIT7                       1006
#define IDC_LIST1                       1007
#define IDC_EDIT8                       1007
#define IDC_EDIT_CT                     1007
#define IDC_TAB1                        1008
#define IDC_EDIT9                       1008
#define IDC_IMAGEFRAME                  1009
#define IDC_OPENFILE                    1010
#define IDC_RADIO_FIT                   1011
#define IDC_RADIO_10                    1012
#define IDC_SLIDER1                     1012
#define IDC_SLIDER_EXPORSUR             1012
#define IDC_RADIO_25                    1013
#define IDC_BUTTON1                     1013
#define IDC_RADIO_50                    1014
#define IDC_BUTTON2                     1014
#define IDC_RADIO_100                   1015
#define IDC_BUTTON3                     1015
#define IDC_BUTTON4                     1016
#define IDC_COMBO1                      1017
#define IDC_CTRLPANEL_FRAME             1018
#define IDC_COMBO2                      1018
#define IDC_SLIDER_EXPORSUR2            1018
#define IDC_SLIDER_BA                   1018
#define IDC_CHECK1                      1019
#define IDC_SLIDER_EXPORSUR3            1019
#define IDC_SLIDER_MG                   1019
#define IDC_PROGRESS1                   1020
#define IDC_SLIDER_CON                  1020
#define IDC_SLIDER_SHR                  1021
#define IDC_SLIDER_TOME                 1022
#define IDC_SLIDER_TONE                 1022
#define IDC_SLIDER_SATU                 1023
#define IDC_COMBO3                      1024
#define IDC_COMBO_FE                    1024
#define IDC_COMBO4                      1025
#define IDC_COMBO_TE                    1025
#define IDC_COMBO5                      1026
#define IDC_COMBO_CS                    1026
#define IDC_CHECK2                      1027
#define IDC_CHECK_CASHE                 1027
#define IDC_BUTTON5                     1028
#define IDC_BUTTON6                     1029
#define IDC_COMBO_PS                    1030
#define IDC_COMBO_WB                    1031
#define IDC_BUTTON_SAVE                 1032
#define IDC_AFFRAME                     1033
#define IDC_TONECURVE                   1034
#define IDC_AFFRAME_VIEW                1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
