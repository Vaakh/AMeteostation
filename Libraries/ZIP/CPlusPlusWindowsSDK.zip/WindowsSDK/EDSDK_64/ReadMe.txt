-----------------------------------------------------------------------------------
                             EDSDK 64-bit Library
                                 README File
                           Copyright CANON INC. 2014
-----------------------------------------------------------------------------------
This Readme file contains the latest information about the EDSDK 64-bit Library.
Please read this file before using the EDSDK 64-bit Library.
-----------------------------------------------------------------------------------

About EDSDK 64-bit library
------------------
Limited to the camera connect functions, we released a 64-bit library as a beta 
version on a trial basis. 

Since we don't support functions to handle image file in the 64-bit library, 
the EdsCreateImageRef will be an error.
